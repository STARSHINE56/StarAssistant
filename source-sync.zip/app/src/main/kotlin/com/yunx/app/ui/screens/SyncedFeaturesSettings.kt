package com.yunx.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.yunx.app.data.prefs.SettingsRepository
import com.yunx.app.util.DiagnosticLog
import com.yunx.app.util.LogExporter
import com.yunx.app.ui.SnackbarController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun SyncedFeaturesSettings(onEngineClick: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { SettingsRepository(context) }
    val scope = rememberCoroutineScope()
    var noSave by remember { mutableStateOf(settings.quarkNoSaveDownload) }
    var diagnostic by remember { mutableStateOf(settings.diagnosticMode) }
    var sourceDialog by remember { mutableStateOf(false) }
    var announcementSource by remember { mutableStateOf(settings.announcementBaseUrl) }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton(onClick = onEngineClick) { Text("下载引擎：内置 / Gopeed（磁力下载）") }
            Row(Modifier.fillMaxWidth()) {
                Text("夸克免转存下载", Modifier.weight(1f))
                Switch(noSave, { noSave = it; settings.quarkNoSaveDownload = it })
            }
            Text("开启后优先通过分享凭证取链，失败时回退转存。", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth()) {
                Text("诊断模式（模块日志）", Modifier.weight(1f))
                Switch(diagnostic, { diagnostic = it; settings.diagnosticMode = it; DiagnosticLog.setEnabled(context, it) })
            }
            TextButton(onClick = { scope.launch {
                val file = withContext(Dispatchers.IO) { LogExporter.exportDiagnosticZip(context) }
                if (file != null) LogExporter.share(context, file) else SnackbarController.show("暂无诊断日志，请开启诊断模式后复现问题")
            } }) { Text("导出诊断日志") }
            TextButton(onClick = { sourceDialog = true }) { Text(if (announcementSource.isBlank()) "公告来源：未配置" else "公告来源：已配置") }
        }
    }
    Spacer(Modifier.height(6.dp))
    if (sourceDialog) {
        var input by remember { mutableStateOf(announcementSource) }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest = { sourceDialog = false }, title = { Text("星辰助手公告来源") }, text = {
            Column {
                Text("填写公告 API 的 HTTPS 基础地址。留空关闭公告；保存后重启应用生效。")
                OutlinedTextField(input, { input = it; error = null }, label = { Text("HTTPS 地址") }, isError = error != null, singleLine = true)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        }, confirmButton = { TextButton(onClick = {
            runCatching { settings.announcementBaseUrl = input }.onSuccess {
                announcementSource = settings.announcementBaseUrl; sourceDialog = false
                SnackbarController.show("公告来源已保存，重启应用后生效")
            }.onFailure { error = it.message }
        }) { Text("保存") } }, dismissButton = { TextButton(onClick = { sourceDialog = false }) { Text("取消") } })
    }
}
